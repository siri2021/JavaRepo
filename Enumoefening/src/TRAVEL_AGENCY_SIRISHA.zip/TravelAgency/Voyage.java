package TravelAgency;

public class Voyage {

}
