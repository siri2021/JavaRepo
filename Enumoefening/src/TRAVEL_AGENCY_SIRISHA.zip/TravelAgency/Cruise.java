package TravelAgency;

public class Cruise {

}
