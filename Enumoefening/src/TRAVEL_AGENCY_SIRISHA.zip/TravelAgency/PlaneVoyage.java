package TravelAgency;

public class PlaneVoyage {

}
