package TravelAgency;

public class Agency {

}
