package TravelAgency;

public class CarVoyage extends Voyage {
	
	public static final double CAR_RENTAL_PRICE=10;
	private boolean ownCar;
	
	
//@Override	
//public double calculatePrice() {
	//return CAR_RENTAL_PRICE;
//}
}
