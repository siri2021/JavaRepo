package TravelAgency;

public class Address {

}
