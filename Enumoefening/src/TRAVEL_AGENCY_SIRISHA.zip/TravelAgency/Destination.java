package TravelAgency;

public enum Destination {
	
	    JAPAN, INDIA, MADAGASKAR, BRAZIL
	


}
