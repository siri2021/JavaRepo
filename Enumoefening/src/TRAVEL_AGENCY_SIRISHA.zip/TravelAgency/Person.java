package TravelAgency;

public class Person {

}
