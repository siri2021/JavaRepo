package TravelAgency;

public class ReservationLog {

}
