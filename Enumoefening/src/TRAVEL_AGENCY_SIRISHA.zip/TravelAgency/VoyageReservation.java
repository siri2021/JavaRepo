package TravelAgency;

public class VoyageReservation {

}
